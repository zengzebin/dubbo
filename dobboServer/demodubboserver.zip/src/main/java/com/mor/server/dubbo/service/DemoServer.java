/**
 * 
 */
package com.mor.server.dubbo.service;

/**
 * @author wanggengqi
 * @email wanggengqi@chinasofti.com
 * @date 2014年10月23日 下午1:31:21
 */
public interface DemoServer {

	String sayHello(String str);

}
